extends Sprite2D

func _ready() -> void:
	$".".visible = false
	$Options.visible = false

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT and $".".visible == false:
		Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
		Dialogic.end_timeline()
		$".".visible = true

func _unhandled_input(event: InputEvent) -> void:
	if $".".visible == false and event.is_action_pressed("ui_cancel"):
			Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
			Dialogic.end_timeline()
			$".".visible = true
	elif $".".visible == true and event.is_action_pressed("ui_cancel"):
		$".".visible = false
		Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func _on_back_pressed() -> void:
	$".".visible = false
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)


func _on_quit_pressed() -> void:
	get_tree().quit()


func _on_options_back_pressed() -> void:
	$Options.visible = false


func _on_options_pressed() -> void:
	$Options.visible = true
