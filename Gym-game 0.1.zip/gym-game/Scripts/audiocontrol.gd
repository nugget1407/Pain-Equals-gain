extends HSlider

func _ready():
	value = db_to_linear(AudioServer.get_bus_volume_db(GameState.audio_bus_id))

func _on_value_changed(new_value: float) -> void:
		AudioServer.set_bus_volume_db(GameState.audio_bus_id, linear_to_db(new_value))
		AudioServer.set_bus_mute(GameState.audio_bus_id, new_value <= 0.0)
