extends Node2D

@onready var mainbuttons: VBoxContainer = $Mainbuttons
@onready var options: Sprite2D = $Options

func _ready() -> void:
	mainbuttons.visible = true
	options.visible = false
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)

func _on_start_pressed() -> void:
	get_tree().change_scene_to_file("res://Scenes/Main_world.tscn")
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)


func _on_settings_pressed() -> void:
	mainbuttons.visible = false
	options.visible = true


func _on_back_options_pressed() -> void:
	_ready()
