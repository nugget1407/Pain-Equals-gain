extends CharacterBody2D

const speed = 200
var current_dir = "down"
var body_state = "Fat" #Vi starter tykke
func _ready():
	$AnimatedSprite2D.play("Fat_front_idle")
	GameState.stats_changed.connect(update_body_state)

func _physics_process(delta):
	if Dialogic.current_timeline != null:
		velocity = Vector2.ZERO
		return
	player_movement(delta)

func player_movement(_delta):
	if Input.is_action_pressed("ui_right"):
		current_dir = "right"
		play_anim(1)
		velocity.x = speed
		velocity.y = 0
	elif Input.is_action_pressed("ui_left"):
		current_dir = "left"
		play_anim(1)
		velocity.x = -speed
		velocity.y = 0
	elif Input.is_action_pressed("ui_down"):
		current_dir = "down"
		play_anim(1)
		velocity.y = speed
		velocity.x = 0
	elif Input.is_action_pressed("ui_up"):
		current_dir = "up"
		play_anim(1)
		velocity.y = -speed
		velocity.x = 0
	else:
		play_anim(0)
		velocity.x = 0
		velocity.y = 0
	
	move_and_slide()

func play_anim(movement):
	var anim = $AnimatedSprite2D
	var action = "_walk" if movement == 1 else "_idle"
	var side = ""

	match current_dir:
		"right":
			anim.flip_h = false
			side = "_side"
		"left":
			anim.flip_h = true
			side = "_side"
		"down":
			anim.flip_h = false
			side = "_front"
		"up":
			anim.flip_h = false
			side = "_back"

	anim.play(body_state + side + action)

func update_body_state():
	var old_state = body_state
	if body_state == "Fat" and GameState.Lean > 5:
		body_state = "Skinny"
	elif GameState.Strength > 8:
		body_state = "Buff"
	elif GameState.Strength > 3:
		body_state = "Lean"
	if body_state != old_state:
		play_anim(0)
