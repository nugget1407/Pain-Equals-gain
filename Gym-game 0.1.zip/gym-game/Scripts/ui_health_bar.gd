extends Sprite2D

func _ready() -> void:
	frame = GameState.Health
	GameState.Health_changed.connect(_on_Health_changed)

func _on_Health_changed(value):
	frame = value
