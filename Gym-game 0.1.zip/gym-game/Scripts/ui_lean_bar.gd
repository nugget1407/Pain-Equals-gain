extends Sprite2D

func _ready() -> void:
	frame = GameState.Lean
	GameState.Lean_changed.connect(_on_Lean_changed)

func _on_Lean_changed(value):
	frame = value
