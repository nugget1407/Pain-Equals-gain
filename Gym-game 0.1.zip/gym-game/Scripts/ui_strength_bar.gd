extends Sprite2D

func _ready() -> void:
	frame = GameState.Strength
	GameState.Strength_changed.connect(_on_Strength_changed)

func _on_Strength_changed(value):
	frame = value
