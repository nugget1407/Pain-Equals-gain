extends Node2D

func _ready() -> void:
	visible = false

func _unhandled_key_input(event: InputEvent) -> void:
	if event.is_action_pressed("E"):
		visible = !visible
