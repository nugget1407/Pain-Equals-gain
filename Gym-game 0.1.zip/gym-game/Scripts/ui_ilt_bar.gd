extends Sprite2D

func _ready() -> void:
	frame = GameState.Ilt
	GameState.Ilt_changed.connect(_on_Ilt_changed)

func _on_Ilt_changed(value):
	frame = value
