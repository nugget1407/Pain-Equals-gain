extends Sprite2D

func _ready() -> void:
	frame = GameState.Restitution
	GameState.Restitution_changed.connect(_on_Restitution_changed)

func _on_Restitution_changed(value):
	frame = value
