extends Node

var audio_bus_name: String = "Master"
var audio_bus_id: int

var Health := 0
var Ilt := 0
var Lean := 0:
	set(value):
		Lean = value
		stats_changed.emit()
var Restitution := 0
var Speed := 0
var Strength := 0:
	set(value):
		Strength = value
		stats_changed.emit()

const MAX_Health := 10
const MAX_Ilt := 10
const MAX_Lean := 11
const MAX_Restitution := 1
const MAX_Speed := 11
const MAX_Strength := 11

signal Health_changed(value)
signal Ilt_changed(value)
signal Lean_changed(value)
signal Restitution_changed(value)
signal Speed_changed(value)
signal Strength_changed(value)
signal stats_changed

var completed_dialogues: Dictionary = {
	"test karakter slet": false,
}


func _ready():
	audio_bus_id = AudioServer.get_bus_index(audio_bus_name)

func _on_dialogic_signal(argument: String):
	if argument == "Health":
		add_Health()
	if argument == "Ilt":
		add_Ilt()
	if argument == "Lean":
		add_Lean()
	if argument == "Restitution":
		add_Restitution()
	if argument == "Speed":
		add_Health()
	if argument == "Strength":
		add_Strength()
		print("+strength")

func add_Health(amount := 1):
	Health = clamp(Health + amount, 0, MAX_Health)
	Health_changed.emit(Health)
func add_Ilt(amount := 1):
	Ilt = clamp(Ilt + amount, 0, MAX_Ilt)
	Ilt_changed.emit(Health)
func add_Lean(amount := 1):
	Lean = clamp(Lean + amount, 0, MAX_Lean)
	Lean_changed.emit(Health)
func add_Restitution(amount := 1):
	Restitution = clamp(Restitution + amount, 0, MAX_Restitution)
	Restitution_changed.emit(Health)
func add_Speed(amount := 1):
	Speed = clamp(Speed + amount, 0, MAX_Speed)
	Speed_changed.emit(Health)
func add_Strength(amount := 1):
	Strength = clamp(Strength + amount, 0, MAX_Strength)
	Strength_changed.emit(Health)
