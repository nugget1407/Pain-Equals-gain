extends Sprite2D

func _ready() -> void:
	frame = GameState.Speed
	GameState.Speed_changed.connect(_on_Speed_changed)

func _on_Speed_changed(value):
	frame = value
