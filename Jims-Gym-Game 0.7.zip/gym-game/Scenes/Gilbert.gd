extends Node2D

const CATEGORIES := ["Meat", "Vegan", "Snacks", "More"]

var shop_items: Array[Dictionary] = [
	{"name": "Kyllingelår", "category": "Meat",
		"icon": preload("res://Art and textures/Textures/mad/ikoner/chicken_small.webp"), "image": preload("res://Art and textures/Textures/mad/stor/chicken_big.webp"),
		"kcal": 220, "protein": 25, "fedt": 10, "kulhydrat": 0},
	{"name": "Æg", "category": "Meat",
		"icon": preload("res://Art and textures/Textures/mad/ikoner/egg_small.webp"), "image": preload("res://Art and textures/Textures/mad/stor/egg_big.webp"),
		"kcal": 68, "protein": 6.2, "fedt": 4.6, "kulhydrat": 0.6},
	{"name": "Avocado", "category": "Vegan",
		"icon": preload("res://Art and textures/Textures/mad/ikoner/avocado_small.webp"), "image": preload("res://Art and textures/Textures/mad/stor/avocado_big.webp"),
		"kcal": 249, "protein": 2.8, "fedt": 19, "kulhydrat": 13.1, "fibre": 7.5},
	{"name": "Æble", "category": "Vegan",
		"icon": preload("res://Art and textures/Textures/mad/ikoner/apple_small.webp"), "image": preload("res://Art and textures/Textures/mad/stor/apple_big.webp"),
		"kcal": 60, "protein": 0.3, "fedt": 0.2, "kulhydrat": 13.3, "fibre": 2.4},
	{"name": "Appelsin", "category": "Vegan",
		"icon": preload("res://Art and textures/Textures/mad/ikoner/orange_small.webp"), "image": preload("res://Art and textures/Textures/mad/stor/orange_big.webp"),
		"kcal": 69, "protein": 1.3, "fedt": 0.1, "kulhydrat": 14.3, "fibre": 2.8},
	{"name": "Broccoli", "category": "Vegan",
		"icon": preload("res://Art and textures/Textures/mad/ikoner/broccoli_small.webp"), "image": preload("res://Art and textures/Textures/mad/stor/broccoli_big.webp"),
		"kcal": 32, "protein": 3.2, "fedt": 0.2, "kulhydrat": 2.8},
	{"name": "Proteindrik", "category": "More",
		"icon": preload("res://Art and textures/Textures/mad/ikoner/protein_drink_small.webp"), "image": preload("res://Art and textures/Textures/mad/stor/protein_drink_big.webp"),
		"kcal": 216, "protein": 26, "fedt": 4.5, "kulhydrat": 24},
]

var current_tab := 0 
var current := 0     

func _ready() -> void:
	refresh()

func _unhandled_input(event: InputEvent) -> void:
	var items := items_in_tab()
	if event.is_action_pressed("ui_up"):
		current_tab = posmod(current_tab - 1, CATEGORIES.size())
		current = 0
		refresh()
	elif event.is_action_pressed("ui_down"):
		current_tab = (current_tab + 1) % CATEGORIES.size()
		current = 0
		refresh()
	elif event.is_action_pressed("ui_left") and not items.is_empty():
		current = posmod(current - 1, items.size())
		refresh()
	elif event.is_action_pressed("ui_right") and not items.is_empty():
		current = (current + 1) % items.size()
		refresh()
	elif event.is_action_pressed("ui_accept") and not items.is_empty():
		var item_name: String = items[current]["name"]
		if not Inventory.has_item(item_name):
			Inventory.add_item(item_name, items[current]["icon"])
		refresh()
	if event.is_action_pressed("ui_cancel"):
		get_tree().change_scene_to_file("res://Scenes/Main_world.tscn")


func items_in_tab() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for item in shop_items:
		if item["category"] == CATEGORIES[current_tab]:
			result.append(item)
	return result

func refresh() -> void:
	$Panelet.frame = current_tab
	var items := items_in_tab()

	for child in $IconGrid.get_children():
		child.queue_free()
	for i in items.size():
		var icon := TextureRect.new()
		icon.texture = items[i]["icon"]
		icon.custom_minimum_size = Vector2(32, 32)
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		if i != current:
			icon.modulate = Color(1, 1, 1, 0.4)  
		$IconGrid.add_child(icon)

	if items.is_empty():
		$Sprite2D.texture = null
		$Label.text = "Nothingness..."
		return

	var item: Dictionary = items[current]
	$Sprite2D.texture = item["image"]

	var text: String = item["name"].to_upper() + "\n\n"
	text += "Kalorier: %s kcal\n\n" % fmt(item["kcal"])
	text += "Protein: %s g\n" % fmt(item["protein"])
	text += "Fedt: %s g\n" % fmt(item["fedt"])
	text += "Kulhydrat: %s g\n" % fmt(item["kulhydrat"])
	if item.has("fibre"):
		text += "Kostfibre: %s g\n" % fmt(item["fibre"])
	if Inventory.has_item(item["name"]):
		text += "\nI din taske"
	else:
		text += "\nkøb\n[Enter]"
	$Label.text = text

func fmt(value: float) -> String:
	if is_equal_approx(value, roundf(value)):
		return str(int(value))
	return str(value).replace(".", ",")
