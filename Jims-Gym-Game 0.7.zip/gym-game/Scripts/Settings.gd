extends Sprite2D

func _ready() -> void:
	add_to_group("pause_menu")
	visible = false
	$Options.visible = false

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT and not visible:
		open_menu()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		if visible:
			close_menu()
		else:
			open_menu()

func open_menu() -> void:
	get_tree().call_group("inventory", "close")
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	Dialogic.end_timeline()
	visible = true

func close_menu() -> void:
	visible = false
	$Options.visible = false
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func _on_back_pressed() -> void:
	close_menu()

func _on_quit_pressed() -> void:
	get_tree().quit()

func _on_options_back_pressed() -> void:
	$Options.visible = false

func _on_options_pressed() -> void:
	$Options.visible = true
