extends Node

signal item_added(item_name: String)

var items: Array[String]=[]
var icons: Dictionary = {}

func add_item(item_name: String, icon: Texture2D = null) -> void:
	items.append(item_name)
	icons[item_name] = icon
	item_added.emit(item_name)

func has_item(item_name:String) -> bool:
	return item_name in items
