extends Node2D

const SLOT_SIZE := Vector2(16, 16)

func _ready() -> void:
	add_to_group("inventory")
	visible = false
	Inventory.item_added.connect(_on_item_added)
	update_list()

func _unhandled_key_input(event: InputEvent) -> void:
	if event.is_action_pressed("E"):
		var pause_menu := get_tree().get_first_node_in_group("pause_menu")
		if pause_menu and pause_menu.visible:
			return
		visible = !visible
		if visible:
			Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
		else:
			Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func close() -> void:
	if visible:
		visible = false
		Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func _on_item_added(_item_name: String) -> void:
	update_list()

func update_list() -> void:
	for child in $SlotGrid.get_children():
		child.queue_free()
	for item_name in Inventory.items:
		var icon := TextureRect.new()
		icon.texture = Inventory.icons.get(item_name)
		icon.custom_minimum_size = SLOT_SIZE
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		icon.tooltip_text = item_name
		$SlotGrid.add_child(icon)
