extends Control

var hp=100
var Fjende_HP=100

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$Fight.pressed.connect(attack)
	$act.pressed.connect(act)
	
	$Spiller.max_value=100
	$Fjende.max_value=100
	
	$Spiller.show_percentage = false
	$Fjende.show_percentage = false
	
	update_hp()

func attack() -> void:
	Fjende_HP -= 20
	$Message.text = "Kachow!!!"
	update_hp()
	$Fight.disabled = true
	$act.disabled = true
	await get_tree().create_timer(2.0).timeout
	Fjende_turn()

func act() -> void:
	$Message.text = "You acted typeshit"
	$Fight.disabled = true
	$act.disabled = true
	await get_tree().create_timer(2.0).timeout
	Fjende_turn()

func Fjende_turn() -> void:
	if Fjende_HP > 0:
		hp -=10
		$Message.text = "av :("
		$Fight.disabled = false
		$act.disabled = false
	else:
		$Mus.visible = false
		$Message.text = "Du vandt"
	if hp <= 0:
		$Message.text = "Du tabte"
	update_hp()
	
func update_hp():
	hp = max(hp,0)
	Fjende_HP = max (Fjende_HP, 0)
	
	$HP.text= "HP: " + str(hp)
	$FjendeHP.text= "HP: " + str(Fjende_HP)
	
	$Spiller.value = hp
	$Fjende.value = Fjende_HP
	
	if hp <=0 or Fjende_HP <= 0:
		$Fight.disabled = true
		$act.disabled = true
		await get_tree().create_timer(5.0).timeout
		get_tree().change_scene_to_file("res://Scenes/Main_world.tscn")
