extends Node2D

func _input(event: InputEvent) -> void:
	if Input.is_action_just_pressed("ui_left"):
		$Sprite2D.frame = posmod($Sprite2D.frame - 1, $Sprite2D.hframes)
	if Input.is_action_just_pressed("ui_right"):
		$Sprite2D.frame = ($Sprite2D.frame + 1) %$Sprite2D.hframes
